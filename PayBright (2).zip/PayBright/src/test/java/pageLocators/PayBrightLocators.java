package pageLocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PayBrightLocators {

	
	@FindBy(xpath="//input[@title='Search']")
	public WebElement GoogleSearchBox;
	
	@FindBy(xpath="//*[contains(@href,'https://paybright.com')]//h3[contains(text(),'PayBright')]")
	public WebElement PayBrightWebSite;
	
	@FindBy(xpath="//a[text()='Shop']")
	public WebElement Shop;
	
	@FindBy(xpath="//li[text()='Popular']")
	public WebElement PopularOption;
	
	@FindBy(xpath="//div[@id='mui-component-select-sort-by']")
	public WebElement SortByDropdown;
	
	
	@FindBy(xpath="//*[contains(@class,'MuiInputBase-inputTypeSearch')]")
	public WebElement MerchantSearchBox;
	
	@FindBy(xpath="//p[text()='Samsung']")
	public WebElement SamsungSearchResult;
	
}
