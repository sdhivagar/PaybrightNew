package pageActions;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import pageLocators.PayBrightLocators;
import utils.SeleniumDriver;

public class PayBrightAction {

	PayBrightLocators PayBrightLocator=null;
	CommonAction cbolCommonActions = new CommonAction();
	final Log log = LogFactory.getLog(PayBrightAction.class.getName());
	public  PayBrightAction()
	{
		this.PayBrightLocator = new PayBrightLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), PayBrightLocator);
	}
	
	public void Entersearchbar(String Search) {
		log.info(">>> Entering Paybright in Google searchBar");
		PayBrightLocator.GoogleSearchBox.click();
		PayBrightLocator.GoogleSearchBox.sendKeys(Search);
		PayBrightLocator.GoogleSearchBox.submit();
	}
	
	public void VerifyPayBrightWebSite() {
		log.info(">>> Verifying Paybright website in dispayed result");
		PayBrightLocator.PayBrightWebSite.isDisplayed();
		String Result = PayBrightLocator.PayBrightWebSite.getText();
		Assert.assertEquals("PayBright: Canada's leading buy now pay later solution ...", Result);
	}
	
	public void NaviagtePayBrightWebSite() throws InterruptedException {
		log.info(">>> Navigating to Paybright website");
		PayBrightLocator.PayBrightWebSite.click();
		log.info(">>> Verifying  PayBright website is loaded ");
		PayBrightLocator.Shop.isDisplayed();
		Assert.assertEquals("PayBright: Canada's leading buy now pay later solution | Paybright", SeleniumDriver.getDriver().getTitle());
	}
	
	public void NaviagteToShopDirectory() {
		log.info(">>> Navigating to Shop Directory");
		PayBrightLocator.Shop.click();
	}
	
	public void SearchingMerchant(String SortBy, String MerchantName) throws InterruptedException {
		log.info(">>> Selecting Popular Option from Dropdwon");
		PayBrightLocator.SortByDropdown.click();
		PayBrightLocator.PopularOption.click();
		Thread.sleep(2000);
		log.info(">>> Entering Merchant Name ");
	    PayBrightLocator.MerchantSearchBox.click();
	    PayBrightLocator.MerchantSearchBox.sendKeys(MerchantName);
	}
   
	public void VerifyingSearchingresult() {
		log.info(">>> Verifying Searching result");
		PayBrightLocator.SamsungSearchResult.isDisplayed();
		String Result = PayBrightLocator.SamsungSearchResult.getText();
		Assert.assertEquals("Samsung", Result);
	}
	
}
